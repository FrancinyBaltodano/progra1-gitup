##include "Pokemon.h"
#include "Batalla.h"

int main() {
	// Crear Pok�mon con nombres espec�ficos
	Pokemon pikachu("Pikachu");
	Pokemon charmander("Charmander");
	
	// Iniciar la batalla entre ellos
	Batalla batalla(pikachu, charmander);
	batalla.iniciar();
	
	return 0;
}


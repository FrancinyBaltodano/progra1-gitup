

#include "Batalla.h"
#include <iostream>
using namespace std;

Batalla::Batalla(Pokemon &p, Pokemon &c) : pikachu(p), charmander(c) {}

void Batalla::iniciar() {
	cout << " Batalla entre " << pikachu.getNombre() << " y " << charmander.getNombre() <<;
	
	while (pikachu.estaVivo() && charmander.estaVivo()) {
		pikachu.atacar(charmander);
		if (charmander.estaVivo()) {
			charmander.atacar(pikachu);
		}
	}
	
	cout << "Resultado ";
	if (pikachu.estaVivo()) {
		cout << pikachu.getNombre() << " gan� la batalla";
	} else {
		cout << charmander.getNombre() << " gan� la batalla";
	}
}





#include "Pokemon.h"
#include <iostream>
using namespace std;

Pokemon::Pokemon(string n) {
	nombre = n;
	int vida;
	ataque = 20;
}

void Pokemon::atacar(Pokemon &enemigo) {
	cout << nombre << " ataco  " << enemigo.getNombre() << ;
	enemigo.recibirDanio(ataque);
}

void Pokemon::recibirDanio(int cantidad) {
	vida -= cantidad;
	if (vida < 0) vida = 0;
	cout << "Ahora " << nombre << " tiene " << vida << " de vida" ;
}

bool Pokemon::estaVivo() {
	return vida > 0;
}

string Pokemon::getNombre() {
	return nombre;
}

int Pokemon::getVida() {
	return vida;
}

int Pokemon::getAtaque() {
	return ataque;
}

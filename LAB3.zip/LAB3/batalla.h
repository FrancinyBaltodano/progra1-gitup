
#include "batalla.h"

class batalla {
public:
	batalla(pokemon_pikachu, pokemon_charmander);
	void (iniciar);
private:
	pokemon pikachu;
    pokemon charmander;
};



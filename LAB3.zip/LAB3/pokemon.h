#include <iostream>
include <string>
class pokemon {
private:
	Pokemon(string n) {
		nombre = n;
		int vida;
		ataque = 20;
	}
public:pokemon();
string nombre;
int vida;
int ataque
string GetnombrePokemon();
int GetvidaPokemon();

void SetnombrePokemon(string_nombrePokemon);
void Setataque(int_ataque);
void Setvida(int_vida)
;)

